package main

import (
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"reflect"
	"strconv"
	"strings"
	"time"

	simplejson "github.com/bitly/go-simplejson"
	"github.com/grafana/grafana_plugin_model/go/datasource"
	hclog "github.com/hashicorp/go-hclog"
	plugin "github.com/hashicorp/go-plugin"
	"golang.org/x/net/context"
	"golang.org/x/net/context/ctxhttp"
)

type ClickhouseDatasource struct {
	plugin.NetRPCUnsupportedPlugin
	logger hclog.Logger
}

func (ds *ClickhouseDatasource) Query(ctx context.Context, tsdbReq *datasource.DatasourceRequest) (*datasource.DatasourceResponse, error) {
	jsonData, err := simplejson.NewJson([]byte(tsdbReq.Datasource.JsonData))
	if err != nil {
		return nil, err
	}
	tlsAuth := jsonData.Get("tlsAuthWithCACert").MustBool()
	tlsCACert := tsdbReq.Datasource.DecryptedSecureJsonData["tlsCACert"]

	httpClient := getHttpClient(tlsAuth, &tlsCACert)

	response := &datasource.DatasourceResponse{}
	for _, r := range tsdbReq.Queries {
		queryJson, err := simplejson.NewJson([]byte(r.ModelJson))
		params := url.Values{}
		params["query"] = getQuery(queryJson, tsdbReq.TimeRange)

		ds.logger.Debug("request ", params["query"])
		req, err := ds.createHttpRequest(params, tsdbReq.Datasource.Url)
		if err != nil {
			ds.logger.Warn("creating request failed ", err)
			return nil, err
		}
		res, err := ctxhttp.Do(ctx, httpClient, req)
		if err != nil {
			ds.logger.Warn("http request failed ", err)
			return nil, err
		}

		requestResult, err := ds.parseResponse(res)
		if err != nil {
			ds.logger.Warn("parsing response failed ", err)
			continue
		}
		qr, err := ds.convertToResult(r, requestResult)
		if err != nil {
			ds.logger.Warn("converting to result failed ", err)
			continue
		}
		response.Results = append(response.Results, qr)
	}

	return response, nil
}

func (ds *ClickhouseDatasource) convertToResult(query *datasource.Query, dto *TargetResponseDTO) (*datasource.QueryResult, error) {
	if len(dto.MetaData) < 2 {
		return nil, fmt.Errorf("Response meta-data contains %d values. Expect at least two values", len(dto.MetaData))
	}

	var timeColumnName string
	// name of the time column always should be first
	if dto.MetaData[0].Type != "UInt64" {
		return nil, fmt.Errorf("First element in metadata must be UInt64")
	}
	queryRes := datasource.QueryResult{
		RefId:  query.RefId,
		Series: make([]*datasource.TimeSeries, 0),
		Tables: make([]*datasource.Table, 0),
	}
	timeColumnName = dto.MetaData[0].Name
	timeSeries := make(map[string]map[float64]float64)
	timeStamps := make([]float64, 0, len(dto.Data))

	for _, series := range dto.Data {
		timeValue, err := extractFloat64(series[timeColumnName])
		if err != nil {
			return nil, fmt.Errorf("Error while parsing timestamp value: %s", err)
		}

		timeStamps = append(timeStamps, timeValue)
		delete(series, timeColumnName)

		for k, v := range series {
			pointValue, err := extractFloat64(v)
			if err == nil {
				if _, ok := timeSeries[k]; !ok {
					timeSeries[k] = make(map[float64]float64)
				}
				timeSeries[k][timeValue] = pointValue
				continue
			}

			// Since ClickHouse may return arrays if using `groupArray` we need to process it right
			// No guarantees that `groupArray` will return same number of names in each array
			// That's why we need to create them by ourselves to provide same amount of datapoints
			if reflect.TypeOf(v).Kind() != reflect.Slice {
				return nil, fmt.Errorf("PointValue parsing error: %s", err)
			}

			groupArr := v.([]interface{})
			for _, group := range groupArr {
				tuple, ok := group.([]interface{})
				if !ok {
					return nil, fmt.Errorf("Unexpected tuple type: %T. Expected []interface{}", tuple)
				}
				if len(tuple) != 2 {
					return nil, fmt.Errorf("Unexpected tuple array length: %d. Expected 2", len(tuple))
				}

				key, ok := tuple[0].(string)
				if !ok {
					return nil, fmt.Errorf("Unexpected key type: %T. Expected string", key)
				}

				pointValue, err := extractFloat64(tuple[1])
				if err != nil {
					return nil, fmt.Errorf("PointValue parsing error: %s", err)
				}

				if _, ok := timeSeries[key]; !ok {
					timeSeries[key] = make(map[float64]float64)
				}
				timeSeries[key][timeValue] = pointValue
			}
		}
	}

	//ds.logger.Debug("qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq ", query)
	//ds.logger.Debug("timeSeriestimeSeriestimeSeriestimeSeries ", timeSeries)

	// Grafana developers made announce that alerts will be supported by singlestat and tables
	// but now all datasources working only with tsdb.TimeSeries
	for target, points := range timeSeries {
		dataPoints := &datasource.TimeSeries{Name: target}
		for _, t := range timeStamps {
			dataPoints.Points = append(dataPoints.Points, &datasource.Point{
				Timestamp: int64(t),
				Value:     points[t],
			})
		}
		queryRes.Series = append(queryRes.Series, dataPoints)
	}

	return &queryRes, nil
}

func getQuery(queryJson *simplejson.Json, timeRange *datasource.TimeRange) []string {
	result := ""
	timeFilterQuery := queryJson.Get("timeFilterQuery").MustString()
	if timeFilterQuery == "" {
		result = queryJson.Get("rawQuery").MustString()
	} else {
		fromSecs := timeRange.GetFromEpochMs() / 1000
		toSecs := timeRange.GetToEpochMs() / 1000
		r := strings.NewReplacer(
			"$from", strconv.FormatInt(fromSecs, 10),
			"$to", strconv.FormatInt(toSecs, 10),
		)
		result = r.Replace(timeFilterQuery)
	}
	return []string{result + " FORMAT JSON"}
}

func (ds *ClickhouseDatasource) createHttpRequest(data url.Values, link string) (*http.Request, error) {
	u, _ := url.Parse(link)
	u.RawQuery = data.Encode()

	req, err := http.NewRequest(http.MethodGet, u.String(), nil)
	if err != nil {
		ds.logger.Info("Failed to create request", "error", err)
		return nil, fmt.Errorf("Failed to create request. error: %v", err)
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	return req, err
}

func (ds *ClickhouseDatasource) parseResponse(res *http.Response) (*TargetResponseDTO, error) {
	var data TargetResponseDTO

	body, err := ioutil.ReadAll(res.Body)
	defer res.Body.Close()

	if err != nil {
		return nil, err
	}

	if res.StatusCode/100 != 2 {
		return nil, fmt.Errorf("Request failed status: %v", res.Status)
	}

	err = json.Unmarshal(body, &data)
	if err != nil {
		return nil, err
	}

	return &data, nil
}

func getHttpClient(tlsAuth bool, tlsCACert *string) *http.Client {
	transport := &http.Transport{
		TLSClientConfig: &tls.Config{
			Renegotiation: tls.RenegotiateFreelyAsClient,
		},
		Proxy: http.ProxyFromEnvironment,
		Dial: (&net.Dialer{
			Timeout:   30 * time.Second,
			KeepAlive: 30 * time.Second,
			DualStack: true,
		}).Dial,
		TLSHandshakeTimeout:   10 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
		MaxIdleConns:          100,
		IdleConnTimeout:       90 * time.Second,
	}

	if tlsAuth {
		caCertPool := x509.NewCertPool()
		caCertPool.AppendCertsFromPEM([]byte(*tlsCACert))

		transport.TLSClientConfig.RootCAs = caCertPool
	}

	return &http.Client{
		Transport: transport,
		Timeout:   time.Duration(time.Second * 30),
	}
}

func extractFloat64(v interface{}) (float64, error) {
	switch v.(type) {
	case string:
		return strconv.ParseFloat(v.(string), 64)
	case float64:
		return v.(float64), nil
	case nil:
		return float64(0), nil
	default:
		return 0, fmt.Errorf("Unexpected type: %T", v)
	}
}
